package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply {
    int a=0,b=0,mul=0;
    public Multiply(int firstDigit, int secondDigit){
        int a = firstDigit;
        int b = secondDigit;
        mul = a*b;
    }

    public String toString() {
        return String.valueOf(mul);
    }
    // TODO -- start your code here
}
