package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    int a=0,b=0,d=0,r=0;
    public Divide(int firstDigit, int secondDigit){
        int a = firstDigit;
        int b = secondDigit;
        d=a/b;
        r=a%b;
    }


    public String toString() {
        return String.valueOf(d) + "  R: " + String.valueOf(r);
    }
}
    // TODO -- start your code here



