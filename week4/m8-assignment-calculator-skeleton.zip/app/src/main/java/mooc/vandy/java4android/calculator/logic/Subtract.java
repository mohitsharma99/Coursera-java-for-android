package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    int a=0,b=0,sub=0;
    public Subtract(int firstDigit, int secondDigit){
        int a = firstDigit;
        int b = secondDigit;
        sub=a-b;
    }

    public String toString() {
        return String.valueOf(sub);
    }
    // TODO -- start your code here
}
