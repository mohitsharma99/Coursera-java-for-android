package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    int a=0,b=0,sum=0;
    public Add(int firstDigit, int secondDigit){
        int a = firstDigit;
        int b = secondDigit;
        sum = a+b;
    }

    public String toString() {
        return String.valueOf(sum);
    }
    // TODO -- start your code here
}
